// Java Syntax
// We created a Java file called Main.java, and we used the following code to print "Hello World" to the screen
// then press Enter. You can now see whitespace characters in your code.
// Note: The curly braces {} marks the beginning and the end of a block of code.
// Note: that each code statement must end with a semicolon (;).
public class Main {
    /* Every line of code that runs in Java must be inside a class. In our example,
    we named the class Main. A class should always start with an uppercase first letter.*/
    // Note: Java is case-sensitive: "MyClass" and "myclass" has different meaning.
    // -->The name of the java file must match the class name

    // The main() method is required and you will see it in every Java program
    public static void main(String[] args) {
        // Any code inside the main() method will be executed
        // IntelliJ IDEA suggests fixing it.
        System.out.printf("Hello Word!"); // we can use the println() method to print a line of text to the screen


    }
}