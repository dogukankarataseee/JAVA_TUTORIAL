// Java Math
// The Java Math class has many methods that allows you to perform mathematical tasks on numbers.
public class Main {
    public static void main(String[] args) {
        int a,b,d,e;
        double c;
        a = Math.max(5, 10); // The Math.max(x,y) method can be used to find the highest value of x and y
        b = Math.min(5, 10); // The Math.min(x,y) method can be used to find the lowest value of x and y
        c = Math.sqrt(64); // The Math.sqrt(x) method returns the square root of x
        d = (int)(Math.random()*101); // 0 to 100
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);


    }
}