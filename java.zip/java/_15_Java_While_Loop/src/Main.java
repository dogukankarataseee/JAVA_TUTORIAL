// Java While Loop
//The while loop loops through a block of code as long as a specified condition is true
/*
while (condition) {
        // code block to be executed
        }

do {
  // code block to be executed
}
while (condition);

*/

public class Main {
    public static void main(String[] args) {
        int i = 0;
        while (i < 5) {
            System.out.println(i);
            i++;


            int k = 0;
            do {
                System.out.println(k);
                k++;
            }
            while (k < 5);

        }
    }
}