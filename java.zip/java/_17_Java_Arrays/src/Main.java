/*
--> Java Arrays
-Arrays are used to store multiple values in a single variable, instead of declaring separate variables for each value.
To declare an array, define the variable type with square brackets:
String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};
int[] myNum = {10, 20, 30, 40};
*/
public class Main {
    public static void main(String[] args) {

        String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};
        // Acces to items
        System.out.println(cars[0]);
        // Outputs Volvo
        cars[0] = "Opel";
        System.out.println(cars[0]);
        // Now outputs Opel instead of Volvo
        // To find out how many elements an array has, use the length property
        System.out.println(cars.length);
        // Outputs 4
        /*
        Multidimensional Arrays
        --> A multidimensional array is an array of arrays.
        --> Multidimensional arrays are useful when you want to store data as a tabular form, like a table with rows and columns.
        --> To create a two-dimensional array, add each array within its own set of curly braces
        */
        int[][] myNumbers = { {1, 2, 3, 4}, {5, 6, 7} };
        System.out.println(myNumbers[1][2]); // Outputs 7

    }
}