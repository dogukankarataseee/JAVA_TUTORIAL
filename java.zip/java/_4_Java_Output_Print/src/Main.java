
// Print Numbers


public class Main {
    public static void main(String[] args) {

        // You can add as many println() methods as you want.
        // Java Output / Print
        System.out.println("Hello and welcome!");
        System.out.println("Hi I'm Dogukan");
        System.out.println("I'm Electric and Electronic Engineer");
        System.out.printf("Game Over"); //that it does not insert a new line at the end of the output

        // Print Numbers
        // You can also use the println() method to print numbers
        System.out.println(3);
        System.out.println(358);
        System.out.println(50000);
        // you can also perform mathematical calculations inside the println() method
        System.out.println(3*4);

    }
}